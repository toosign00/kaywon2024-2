const express = require("express");
const router = express.Router();
const mainLayout = "../views/layouts/main.ejs";

// "/home" 라우트
router.get(["/", "/home"], (req, res) => {
  res.render("index", { layout: mainLayout });
});

// "/about" 라우트
router.get("/about", (req, res) => {
  res.render("about", { layout: mainLayout });
});

module.exports = router;