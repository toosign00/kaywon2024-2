const mongoose = require("mongoose");
const asyncHandler = require("express-async-handler");
require("dotenv").config();

// DB 연결
const connectDb = asyncHandler(async () => {
  // .env에 있는 MONGO_URI 가져오기
  const connect = await mongoose.connect(process.env.MONGO_URI);
  console.log(`MongoDB Connected: ${connect.connection.host}`); // 연결 성공 시 터미널에  출력
});


module.exports = connectDb; 